import { useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowDown, ArrowRight, ArrowUpRight, Check, ChevronDown, Menu, MessageCircle, X } from 'lucide-react';
import catalog from '@/data/catalog.json';

type Design = { name: string; category: string; image: string; sourceAsset: string; portfolioPage: number };
const designs = catalog as Design[];
const phone = '+919909663883';
const categories = ['All designs', 'Floral design', 'Geometric design', 'Marble design'];
const navItems = [
  ['About', '#about'], ['Portfolio', '#portfolio'], ['Services', '#services'],
  ['Process', '#process'], ['FAQs', '#faqs'], ['Contact', '#contact'],
];

function WhatsAppLink({ children, className = '', message }: { children: ReactNode; className?: string; message?: string }) {
  const href = `https://wa.me/${phone.replace('+', '')}${message ? `?text=${encodeURIComponent(message)}` : ''}`;
  return <a className={className} href={href} target="_blank" rel="noopener noreferrer" data-testid="link-whatsapp">{children}</a>;
}

function Header() {
  const [open, setOpen] = useState(false);
  return <header className="site-header" data-testid="site-header">
    <a href="#home" className="brand" data-testid="link-home" aria-label="Rafai and Creators home">
      <span className="brand-mark">R<span>&</span>C</span><span className="brand-name">RAFAI <i>&</i> CREATORS<small>WALL & TILE DESIGN STUDIO</small></span>
    </a>
    <button className="mobile-menu" onClick={() => setOpen(!open)} aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open} data-testid="button-mobile-menu">{open ? <X/> : <Menu/>}</button>
    <nav className={open ? 'main-nav open' : 'main-nav'} aria-label="Main navigation">
      {navItems.map(([label, href]) => <a key={label} href={href} onClick={() => setOpen(false)} data-testid={`nav-${label.toLowerCase()}`}>{label}</a>)}
      <a className="nav-cta" href="#inquiry" onClick={() => setOpen(false)} data-testid="nav-inquiry">Make an enquiry <ArrowRight size={14}/></a>
    </nav>
  </header>;
}

function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="eyebrow"><span aria-hidden="true"></span>{children}</p>;
}

function Portfolio() {
  const [filter, setFilter] = useState('All designs');
  const [showAll, setShowAll] = useState(false);
  const filtered = useMemo(() => filter === 'All designs' ? designs : designs.filter(d => d.category === filter), [filter]);
  const shown = showAll ? filtered : filtered.slice(0, 9);
  return <section id="portfolio" className="section portfolio-section">
    <div className="section-top">
      <div><SectionLabel>THE DESIGN LIBRARY</SectionLabel><h2>Patterns with <em>presence.</em></h2><p className="section-intro">A considered collection of florals, geometry and marble—each design an invitation to look a little closer.</p></div>
      <a href="#inquiry" className="text-link">Find your design <ArrowRight size={16}/></a>
    </div>
    <div className="filter-row" role="group" aria-label="Filter designs">
      {categories.map(cat => <button key={cat} className={filter === cat ? 'filter active' : 'filter'} onClick={() => { setFilter(cat); setShowAll(false); }} data-testid={`filter-${cat.toLowerCase().replaceAll(' ', '-')}`}>{cat}</button>)}
      <span className="filter-count">{filtered.length} designs</span>
    </div>
    <div className="design-grid">
      {shown.map((design, i) => <article className={`design-card card-${i % 6}`} key={design.name} data-testid={`card-design-${design.name.toLowerCase().replaceAll(' ', '-')}`}>
        <a href={design.image} target="_blank" rel="noopener noreferrer" className="design-image" aria-label={`View ${design.name}`} data-testid={`link-design-${i}`}>
          <img src={design.image} alt={`${design.name} — ${design.category.toLowerCase()} tile and wall design`} loading={i < 3 ? 'eager' : 'lazy'} width="800" height="900"/>
          <span className="image-open"><ArrowUpRight size={18}/></span>
        </a>
        <div className="design-caption"><div><span>{design.category}</span><h3>{design.name}</h3></div><span className="design-index">{String(i + 1).padStart(2, '0')}</span></div>
      </article>)}
    </div>
    {filtered.length > 9 && <button className="outline-button show-more" onClick={() => setShowAll(!showAll)} data-testid="button-show-more">{showAll ? 'Show fewer designs' : 'Explore all designs'} <ArrowDown size={15} className={showAll ? 'rotate' : ''}/></button>}
  </section>;
}

function InquiryForm() {
  const [submitted, setSubmitted] = useState(false);
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const lines = [
      'Hello Rafai & Creators, I would like to enquire about a design.',
      `Name: ${data.get('name')}`, `Phone: ${data.get('phone')}`,
      `Email: ${data.get('email') || 'Not provided'}`, `Space: ${data.get('space')}`,
      `Design interest: ${data.get('interest') || 'Please advise'}`, `Message: ${data.get('message') || 'I would like to learn more.'}`,
    ];
    setSubmitted(true);
    window.open(`https://wa.me/${phone.replace('+', '')}?text=${encodeURIComponent(lines.join('\n'))}`, '_blank', 'noopener,noreferrer');
  };
  return <form className="inquiry-form" onSubmit={handleSubmit} data-testid="form-inquiry">
    <div className="form-row"><label>Your name<input name="name" autoComplete="name" required placeholder="How should we address you?" data-testid="input-name"/></label><label>Phone number<input name="phone" type="tel" autoComplete="tel" required placeholder="+91" data-testid="input-phone"/></label></div>
    <div className="form-row"><label>Email <span>(optional)</span><input name="email" type="email" autoComplete="email" placeholder="you@example.com" data-testid="input-email"/></label><label>What are you designing?<select name="space" defaultValue="" required data-testid="select-space"><option value="" disabled>Select a space</option><option>Home</option><option>Hospitality</option><option>Retail or workplace</option><option>Other / exploring</option></select></label></div>
    <label>Design direction <span>(optional)</span><select name="interest" defaultValue="" data-testid="select-interest"><option value="">I’m open to suggestions</option><option>Floral</option><option>Geometric</option><option>Marble</option><option>Not sure yet</option></select></label>
    <label>A little about your project <span>(optional)</span><textarea name="message" rows={3} placeholder="Tell us about the feel, colours or surface you have in mind…" data-testid="input-message"/></label>
    <button className="gold-button submit-button" type="submit" data-testid="button-submit-inquiry">{submitted ? <><Check size={16}/> Open WhatsApp again</> : <>Send enquiry on WhatsApp <ArrowUpRight size={16}/></>}</button>
    <p className="form-note">Your details stay in this message. WhatsApp opens so you can review and send it.</p>
  </form>;
}

function Home() {
  const [faqOpen, setFaqOpen] = useState<number | null>(0);
  const faqs = [
    ['What does Rafai & Creators offer?', 'We curate and create distinctive tile and wall design concepts, from jewel-toned florals and geometric trellises to expressive marble looks. Tell us what you have in mind and we can discuss what fits.'],
    ['Can I enquire about a particular design?', 'Absolutely. Share the design name or a screenshot from our portfolio through WhatsApp, along with any details you have about your space.'],
    ['How do I get started?', 'Start with a conversation. A few details about the space, the surface and your preferred mood will help us understand your enquiry.'],
    ['Where are you based?', 'Our studio is based in Wankaner, Rajkot, Gujarat. Please contact us directly to discuss your enquiry.'],
    ['Do you provide installation?', 'Please contact us to discuss what your specific project needs. We do not make general installation promises here.'],
  ];
  return <div className="page-shell">
    <Header/>
    <main id="home">
      <section className="hero">
        <div className="hero-art" aria-hidden="true">
          <div className="hero-image hero-image-back"><img src="/images/portfolio/emerald-green-trellis.webp" alt="" width="474" height="570"/></div>
          <div className="hero-image hero-image-front"><img src="/images/portfolio/royal-magnolia.webp" alt="" width="800" height="900"/></div>
          <div className="orbit-stamp"><span>WANKANER · GUJARAT</span><b>✦</b><small>FORM · SURFACE · STORY</small></div>
        </div>
        <div className="hero-copy">
          <SectionLabel>WALL & TILE DESIGN · WANKANER</SectionLabel>
          <h1>Make room<br/>for <em>wonder.</em></h1>
          <p>Walls and surfaces, reimagined in jewel-toned florals, intricate geometry and marble made memorable.</p>
          <div className="hero-actions"><a href="#portfolio" className="gold-button" data-testid="button-explore-designs">Explore the designs <ArrowRight size={16}/></a><WhatsAppLink className="quiet-link">Speak with our studio <ArrowUpRight size={15}/></WhatsAppLink></div>
          <div className="hero-footnote"><span>01 / 03</span><span className="hero-rule"></span><span>DESIGN THAT STAYS WITH YOU</span></div>
        </div>
        <a className="scroll-cue" href="#about" aria-label="Scroll to about section"><ArrowDown size={15}/></a>
      </section>

      <section className="intro-strip" id="about">
        <div className="intro-mark" aria-hidden="true">R<span>&</span>C</div>
        <div><SectionLabel>A STUDIO FOR DISTINCTIVE SURFACES</SectionLabel><p>We believe a wall can do more than divide a room. It can <em>hold a mood,</em> frame a moment and make the everyday feel considered.</p></div>
        <a href="#process" className="round-link" aria-label="Discover our process"><ArrowDown size={17}/></a>
      </section>

      <Portfolio/>

      <section className="services-section section" id="services">
        <div className="services-heading"><SectionLabel>WHAT WE DO</SectionLabel><h2>From first<br/>thought to <em>finish.</em></h2><p>Every project begins with a conversation. Here’s how we can shape yours.</p><a href="#inquiry" className="text-link">Tell us what you’re imagining <ArrowRight size={16}/></a></div>
        <div className="service-list">
          {[
            ['01','Feature wall designs','Distinctive patterns and palettes for walls that give a room its own character.'],
            ['02','Floor pattern direction','Tile patterns chosen with the room, palette and sense of movement in mind.'],
            ['03','Bathroom surface designs','Expressive marble looks and gold details for a room used every day.'],
            ['04','Personal palette guidance','A conversation about colours, patterns and the feeling you want your space to hold.'],
          ].map(([n,title,body])=><article className="service-item" key={n}><span className="service-number">{n}</span><div><h3>{title}</h3><p>{body}</p></div><span className="service-mark"><ArrowUpRight size={18}/></span></article>)}
        </div>
      </section>

      <section className="process-section" id="process">
        <div className="process-visual"><img src="/images/portfolio/teal-rose-gold-lotus.webp" alt="Teal tile design with rose-gold lotus geometry" loading="lazy" width="800" height="800"/><span className="visual-caption">A DETAIL WORTH NOTICING</span></div>
        <div className="process-copy"><SectionLabel>THE DESIGN PROCESS</SectionLabel><h2>Good design<br/>begins with <em>listening.</em></h2><p className="process-intro">No assumptions. No one-size-fits-all. Just a considered conversation about what your space needs.</p>
          <ol className="steps">{[['01','Tell us about your space','Share the setting, the surfaces and anything you already know.'],['02','Explore the possibilities','We talk through colours, patterns and directions that might feel right.'],['03','Take the next step together','Once the direction is clear, we can discuss the details of your enquiry.']].map(([n,title,body])=><li key={n}><span>{n}</span><div><h3>{title}</h3><p>{body}</p></div></li>)}</ol>
        </div>
      </section>

      <section className="feedback-section section">
        <div className="feedback-ornament" aria-hidden="true">“</div>
        <div className="feedback-content"><SectionLabel>A SPACE FOR REAL WORDS</SectionLabel><h2>Your experience<br/><em>belongs here.</em></h2><p>We’re building this studio with care—and we’d love to hear from the people who have spoken with us. Real feedback, in your own words, will find its place here.</p><WhatsAppLink className="outline-button">Share your feedback <ArrowUpRight size={15}/></WhatsAppLink></div>
        <div className="feedback-art"><img src="/images/portfolio/blue-mandala-bloom.webp" alt="Blue and ivory mandala floral surface design" loading="lazy" width="800" height="800"/></div>
      </section>

      <section className="faq-section section" id="faqs">
        <div><SectionLabel>A FEW THINGS TO KNOW</SectionLabel><h2>Questions,<br/><em>answered.</em></h2><p>Something else on your mind? We’re just a message away.</p><WhatsAppLink className="text-link">Ask us directly <ArrowUpRight size={15}/></WhatsAppLink></div>
        <div className="faq-list">{faqs.map(([q,a],i)=><article className={`faq-item ${faqOpen===i?'expanded':''}`} key={q}><button onClick={()=>setFaqOpen(faqOpen===i?null:i)} aria-expanded={faqOpen===i} data-testid={`button-faq-${i}`}><span>{q}</span><ChevronDown size={18}/></button>{faqOpen===i&&<p>{a}</p>}</article>)}</div>
      </section>

      <section className="inquiry-section" id="inquiry">
        <div className="inquiry-left"><SectionLabel>LET’S BEGIN WITH A HELLO</SectionLabel><h2>What would you<br/>like your walls to <em>say?</em></h2><p>Share a few details. Your enquiry will be prepared as a WhatsApp message for you to review and send.</p><div className="inquiry-direct"><span>Prefer to call or write?</span><a href="tel:+919909663883" data-testid="link-call">+91 99096 63883</a><a href="mailto:srafai.6768@gmail.com" data-testid="link-email">srafai.6768@gmail.com</a></div></div>
        <div className="form-card"><InquiryForm/></div>
      </section>

      <section className="contact-section section" id="contact"><div className="contact-title"><SectionLabel>FIND THE STUDIO</SectionLabel><h2>Rooted in<br/><em>Wankaner.</em></h2></div><div className="contact-details"><p>Local roots. A love for expressive surfaces. Reach out from wherever your project begins.</p><a href="tel:+919909663883"><span>PHONE</span>+91 99096 63883 <ArrowUpRight size={16}/></a><a href="mailto:srafai.6768@gmail.com"><span>EMAIL</span>srafai.6768@gmail.com <ArrowUpRight size={16}/></a><p className="address"><span>STUDIO</span>Wankaner, Rajkot, Gujarat, India</p><WhatsAppLink className="gold-button">Message on WhatsApp <ArrowUpRight size={15}/></WhatsAppLink></div></section>
    </main>
     <footer className="site-footer"><a href="#home" className="footer-brand">RAFAI <i>&</i> CREATORS</a><span>WALL & TILE DESIGN STUDIO · WANKANER, GUJARAT</span><a href="#home" className="back-top">BACK TO TOP ↑</a><small>© {new Date().getFullYear()} Rafai & Creators. All rights reserved.</small></footer>
     <WhatsAppLink
       className="floating-whatsapp"
       message="Hello Rafai & Creators, I would like to discuss a tile or wall design for my space."
     >
       <MessageCircle size={18} aria-hidden="true" />
       <span>WhatsApp</span>
       <ArrowUpRight size={14} aria-hidden="true" />
     </WhatsAppLink>
  </div>;
}

function NotFound() {
  return <main className="not-found"><p className="eyebrow">RAFAI & CREATORS</p><h1>This page is<br/><em>still taking shape.</em></h1><a href="/" className="gold-button">Return home <ArrowRight size={16}/></a></main>;
}

function App() {
  return <Home/>;
}

export default App;